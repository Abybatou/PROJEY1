<?php
        if(isset($_POST["modifier"])){
            $code=$_POST["code"];
            $nom=$_POST["nom"];
            $description=$_POST["description"];
            $budget=$_POST["budget"];
            $date_debut=$_POST["date_debut"];
            $date_fin=$_POST["date_fin"];
            $statut=$_POST["statut"];

            $sql="UPDATE projet set code='$code',nom='$nom',descript='$decription',budget='$budget',date_debut='$date_debut',date_fin='$date_fin',statut='$statut'
            where id=$id";
            mysqli_query($connexion,$sql);
            header("location:index.php");

        }

?>
<div class="col-md-8 offset-2 mt-5">
    <div class="card">
        <div class="card-header bg-primary">
            Modifier un Projet
        </div>
        <div class="card-body">
            <form action="" method="POST">
            <label for="" hidden>Code </label>
                    <input type="text" action="<?php echo $code; ?>"name="code" class="form-control" hidden>

                    <label for="">Nom</label>
                    <input type="text" name="nom" required class="form-control">
        
                    <label for="">Description</label>
                    <input type="text" name="description" required class="form-control">
                    <br>
                    <label for="">Budget</label>
                    <input type="number" name="budget" required class="form-control">
                    <br>
                    <label for="">Date debut</label>
                    <input type="date" name="date_debut" required class="form-control">
                    <br>
                    <label for="">Date Fin</label>
                    <input type="date" name="date_fin" required class="form-control">
                    <br>
                    <label for="">Statut :</label>
                         <select name="statut" id="" required class="form-control">
                         <option value="">TRUE</option>
                         <option value="">FALSE</option>
                        </select>
                        <br>
                    <button type="submit" name="ajouter" class="btn btn-dark">Ajouter</button>
                    <button type="submit" name="annuler" class="btn btn-danger">Retour</button>
                </form>
            </div>

    </div>
    
</div>

